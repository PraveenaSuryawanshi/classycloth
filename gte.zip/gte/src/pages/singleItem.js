import React from "react";
import SingleProduct from "../container/homeContainer";

const SingleItem = (props) => {
    console.warn(props);
    return(
        <>
         <SingleProduct/>
        </>
    )
}

export default SingleItem;